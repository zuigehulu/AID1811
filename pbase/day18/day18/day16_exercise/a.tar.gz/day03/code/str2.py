# str.py

print('ABC\n123')
print('ABC\t123')
print("ABCDE\rab")
print("ABCDE\b\babcd")

print("==ABCD==")
print("==\x41\x42\x43\x44==")  # ABCD
print('\x68\x65\x6c\x6c\x6f')
print("hello")


