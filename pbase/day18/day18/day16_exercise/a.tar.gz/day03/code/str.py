# str.py

s = "welcome to beijing.\nI like python!\nI'm studing..."
print(s)  # 等同于print(s, sep=' ', end='\n')

s2 = """welcome to beijing.
I like python!
I'm studing..."""
print(s2)
